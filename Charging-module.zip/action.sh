#!/system/bin/sh
# 文件重命名为: action.sh
# 功能: 模块启动时的初始化脚本

MODDIR=${0%/*}

# 重置模块描述
sed -i '/^description=/s/=.*$/=/' "$MODDIR/module.prop"
sed -i "/description=/s/$/[😇😇等待充电检测😇😇] /" "$MODDIR/module.prop"
echo "充电模块执行成功请放心使用"