#!/system/bin/sh
# 延迟启动监控服务 (15秒)
MODDIR=${0%/*}

# 等待系统启动完成
sleep 15

# 检查基础服务状态
BOOT_COMPLETED=$(getprop sys.boot_completed)
if [ "$BOOT_COMPLETED" != "1" ]; then
    # 最长等待30秒
    WAIT_COUNT=0
    while [ "$BOOT_COMPLETED" != "1" -a $WAIT_COUNT -lt 30 ]; do
        sleep 1
        BOOT_COMPLETED=$(getprop sys.boot_completed)
        WAIT_COUNT=$((WAIT_COUNT + 1))
    done
fi

# 启动监控服务
"$MODDIR/charge-monitor.sh" &
