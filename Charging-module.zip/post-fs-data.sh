#!/system/bin/sh
# 文件: post-fs-data.sh

MODDIR=${0%/*}

# 设置所有脚本可执行权限
chmod 0755 $MODDIR/*.sh

# 执行初始化脚本
$MODDIR/action.sh
