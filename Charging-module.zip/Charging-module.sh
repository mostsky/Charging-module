#!/system/bin/sh
# 文件: charge-monitor.sh
# 功能: 监控充电状态并自动控制温度伪装

# 创建日志文件（覆盖旧日志）
echo "===== 充电监控服务启动 - $(date "+%Y-%m-%d %H:%M:%S") =====" > "$LOG_FILE"
echo "设备型号: $(getprop ro.product.model)" >> "$LOG_FILE"
echo "Android版本: $(getprop ro.build.version.release)" >> "$LOG_FILE"
echo "当前系统模式: $(getprop sys.boot_completed)" >> "$LOG_FILE"

# ===== 关键节点检查 =====
if [ ! -f "$FAKE_TEMP" ]; then
    echo "[ERROR] 严重错误：未找到fake_temp节点" >> "$LOG_FILE"
    echo "[ERROR] 模块无法正常工作，即将退出" >> "$LOG_FILE"
    
    # 更新模块描述为错误状态
    sed -i 's/description=.*/description=[❌错误：fake_temp节点不存在]/' "$MODDIR/module.prop"
    exit 1
fi

# ===== 等待系统初始化完成 =====
WAIT_TIME=0
MAX_WAIT=30  # 最大等待30秒

while [ "$(getprop sys.boot_completed)" != "1" ] && [ $WAIT_TIME -lt $MAX_WAIT ]; do
    sleep 1
    WAIT_TIME=$((WAIT_TIME + 1))
    echo "等待系统启动完成... ${WAIT_TIME}秒" >> "$LOG_FILE"
done

# 检查是否超过最大等待时间
if [ $WAIT_TIME -ge $MAX_WAIT ]; then
    echo "[WARNING] 超过最大等待时间(${MAX_WAIT}秒)，系统可能未完全启动" >> "$LOG_FILE"
fi

# 添加额外延迟确保服务完全启动
echo "系统准备就绪，再等待2秒确保稳定性" >> "$LOG_FILE"
sleep 2

# ===== 检测机制选择 =====
echo "===== 选择充电检测机制 =====" >> "$LOG_FILE"

# 方法1: 使用标准内核接口
if [ -f "/sys/class/power_supply/battery/status" ]; then
    METHOD="sys"
    echo "检测到标准接口: /sys/class/power_supply/battery/status" >> "$LOG_FILE"
    
# 方法2: 使用备用检测点
elif [ -f "/sys/class/power_supply/usb/online" ]; then
    METHOD="usb"
    echo "检测到备用接口: /sys/class/power_supply/usb/online" >> "$LOG_FILE"
    
# 方法3: 使用Android系统服务
else
    METHOD="dumpsys"
    echo "使用dumpsys电池服务检测状态" >> "$LOG_FILE"
fi

# ===== 主监控循环 =====
echo "===== 开始监控充电状态 =====" >> "$LOG_FILE"

while true; do
    CURRENT_TIME=$(date "+%H:%M:%S")
    CHARGING_STATE=""
    
    # 根据选择的检测机制获取充电状态
    case "$METHOD" in
        sys)
            # 标准内核接口
            CHARGING_STATE=$(cat /sys/class/power_supply/battery/status 2>/dev/null)
            ;;
            
        usb)
            # 备用USB检测点
            ONLINE=$(cat /sys/class/power_supply/usb/online 2>/dev/null)
            [ "$ONLINE" == "1" ] && CHARGING_STATE="Charging" || CHARGING_STATE="Discharging"
            ;;
            
        dumpsys)
            # 检查系统服务是否可用
            if pidof system_server >/dev/null; then
                DUMPSYS_RESULT=$(dumpsys battery)
                CHARGING_STATUS=$(echo "$DUMPSYS_RESULT" | awk '/status/ {print $2}')
                LEVEL=$(echo "$DUMPSYS_RESULT" | awk '/level/ {print $2}')
                TEMP=$(echo "$DUMPSYS_RESULT" | awk '/temperature/ {print $2}')
                
                # 转换数字状态为文本
                case "$CHARGING_STATUS" in
                    2) CHARGING_STATE="Charging" ;;
                    3|4) CHARGING_STATE="Discharging" ;;
                    5) CHARGING_STATE="Full" ;;
                    *) CHARGING_STATE="Unknown" ;;
                esac
            else
                echo "[WARNING] system_server未运行，状态检测可能不准确" >> "$LOG_FILE"
                CHARGING_STATE="Discharging"  # 保守默认值
            fi
            ;;
    esac
    
    # 状态日志记录
    if [ -z "$CHARGING_STATE" ]; then
        echo "[$CURRENT_TIME] 无法获取充电状态" >> "$LOG_FILE"
        CHARGING_STATE="Unknown"
    else
        # 记录详细状态信息
        STATUS_LINE="[$CURRENT_TIME] 充电状态: $CHARGING_STATE"
        if [ "$METHOD" = "dumpsys" ]; then
            STATUS_LINE="${STATUS_LINE} | 电量: ${LEVEL}% | 温度: $((TEMP / 10))℃"
        fi
        echo "$STATUS_LINE" >> "$LOG_FILE"
    fi
    
    # ===== 根据状态设置伪装 =====
    case "$CHARGING_STATE" in
        Charging|Full|5|2)
            # 充电状态：启用伪装
            chmod 0666 "$FAKE_TEMP" 2>/dev/null
            echo 25 > "$FAKE_TEMP" 2>/dev/null
            chmod 0444 "$FAKE_TEMP" 2>/dev/null
            sed -i 's/description=.*/description=[🔋充电中：温度伪装激活]/' "$MODDIR/module.prop"
            ;;
            
        Discharging|Not\ charging|3|4)
            # 放电状态：禁用伪装
            chmod 0666 "$FAKE_TEMP" 2>/dev/null
            echo 0 > "$FAKE_TEMP" 2>/dev/null
            chmod 0444 "$FAKE_TEMP" 2>/dev/null
            sed -i 's/description=.*/description=[⚡未充电：正常模式]/' "$MODDIR/module.prop"
            ;;
            
        *)
            # 未知状态保持原样
            echo "[$CURRENT_TIME] 未知充电状态，不进行任何操作" >> "$LOG_FILE"
            ;;
    esac
    
    # ===== 监控间隔 =====
    # 动态调整检测频率（充电时更频繁）
    if [[ "$CHARGING_STATE" == *"Charging"* || "$CHARGING_STATE" == "Full" || "$CHARGING_STATE" == "5" ]]; then
        INTERVAL=10  # 充电时10秒检测一次
    else
        INTERVAL=20  # 未充电时20秒检测一次
    fi
    
    sleep $INTERVAL
done
